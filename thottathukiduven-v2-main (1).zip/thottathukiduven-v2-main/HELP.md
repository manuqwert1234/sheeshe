
# 🛠️ Installation

https://github.com/sr2echa/ThottaThukiduven/assets/65058816/cab3b2d2-4dd3-4c2b-a1f5-a49b2f299966

# 🔄 How to Update

https://github.com/sr2echa/ThottaThukiduven/assets/65058816/ee8273fa-4ab4-41d4-9dbd-aed8204f47ff

