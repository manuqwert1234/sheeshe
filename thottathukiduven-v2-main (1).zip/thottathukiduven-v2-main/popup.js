if (typeof browser === "undefined") {
  var browser = chrome;
}

function _0xb9dd(t, n) {
  const e = _0x5445();
  return (_0xb9dd = function (t, n) {
    return e[(t -= 184)];
  })(t, n);
}
const _0x2e168a = _0xb9dd;
function _0x5445() {
  const t = [
    "1128wnnFHd",
    "message",
    "Error logg",
    "hJTnq",
    "addEventLi",
    "log",
    "ing out:",
    "none",
    "style",
    "ext/logout",
    "vnBKA",
    "gin",
    "catch",
    "NENna",
    "jTojt",
    "runtime",
    "7141fsPgvh",
    "BgqHr",
    "49651lsbVmy",
    "CtxNK",
    "2884146hGMSwQ",
    "180DvrHUc",
    "11liaXAy",
    "PGkyB",
    "IzsOw",
    "display",
    "xAVoB",
    "logout-uwu",
    "login-form",
    "flex",
    "TZaTa",
    "get",
    "value",
    "uven.verce",
    "length",
    "l.app/api/",
    "6656310hTTBby",
    "WdFdz",
    "success-lo",
    "vjuSL",
    "logout-for",
    "login-butt",
    "Kbmzd",
    "block",
    "nuimv",
    "input",
    "ext/login",
    "storage",
    "n/json",
    "fksic",
    "error",
    "kJjSl",
    "POST",
    "cEWhh",
    "https://th",
    "stener",
    "KoCUp",
    "dAjGo",
    "remove",
    "set",
    "json",
    "726984ouFUUa",
    "JSPXP",
    "jvBMB",
    "disabled",
    "click",
    "potus-pani",
    "QqQgj",
    "panic-butt",
    "credential",
    "Mxhsx",
    "zCJyP",
    "logout-but",
    "sendMessag",
    "then",
    "getElement",
    "DOMContent",
    "Error:",
    "logging ou",
    "applicatio",
    "EfhAC",
    "ton",
    "ById",
    "Loaded",
    "success",
    "ytikg",
    "3024102dAqZjm",
    "c-101",
    "IJJjB",
    "AYLBL",
    "xtEAY",
    "sPbUi",
    "JjteQ",
    "stringify",
    "10cSOHoM",
    "RQMln",
    "Bearer ",
    "^/_(^_^)_/",
    "fcxeB",
    "password",
    "status",
    "trim",
    "local",
    "cpoVr",
    "ottathukid",
    "phone",
    "27621820BhLQLb",
  ];
  return (_0x5445 = function () {
    return t;
  })();
}
(function (t, n) {
  const e = _0xb9dd,
    o = _0x5445();
  for (;;)
    try {
      if (
        592345 ===
        (parseInt(e(187)) / 1) * (-parseInt(e(192)) / 2) +
          -parseInt(e(257)) / 3 +
          parseInt(e(232)) / 4 +
          (parseInt(e(265)) / 5) * (-parseInt(e(191)) / 6) +
          (-parseInt(e(189)) / 7) * (-parseInt(e(278)) / 8) +
          -parseInt(e(207)) / 9 +
          (-parseInt(e(277)) / 10) * (-parseInt(e(193)) / 11)
      )
        break;
      o.push(o.shift());
    } catch (t) {
      o.push(o.shift());
    }
})(),
  document[_0x2e168a(282) + _0x2e168a(226)](_0x2e168a(247) + _0x2e168a(254), () => {
    const t = _0x2e168a,
      n = {
        zCJyP: t(285),
        EfhAC: t(200),
        RQMln: t(214),
        BgqHr: t(280) + t(284),
        xAVoB: function (t, n, e) {
          return t(n, e);
        },
        CtxNK: t(225) + t(275) + t(204) + t(206) + t(287),
        fksic: t(223),
        fcxeB: t(250) + t(219),
        nuimv: t(249) + "t",
        NENna: t(240) + "s",
        Kbmzd: function (t, n) {
          return t === n;
        },
        PGkyB: function (t, n) {
          return t > n;
        },
        KoCUp: t(255),
        xtEAY: t(209) + t(289),
        IzsOw: function (t, n) {
          return t(n);
        },
        IJJjB: t(248),
        QqQgj: function (t, n) {
          return t(n);
        },
        JSPXP: t(225) + t(275) + t(204) + t(206) + t(217),
        dAjGo: t(198),
        AYLBL: function (t) {
          return t();
        },
        jvBMB: t(237) + t(258),
        cpoVr: t(199),
        jTojt: t(211) + "m",
        vjuSL: t(212) + "on",
        JjteQ: t(243) + t(252),
        cEWhh: t(276),
        WdFdz: t(270),
        kJjSl: t(239) + "on",
        vnBKA: t(216),
        TZaTa: t(236),
      },
      e = document[t(246) + t(253)](n[t(274)]),
      o = document[t(246) + t(253)](n[t(185)]),
      s = document[t(246) + t(253)](n[t(210)]),
      c = document[t(246) + t(253)](n[t(263)]),
      r = document[t(246) + t(253)](n[t(224)]),
      a = document[t(246) + t(253)](n[t(208)]),
      u = document[t(246) + t(253)](n[t(222)]);
    async function i() {
      const e = t,
        o = { sPbUi: n[e(215)] };
      browser[e(218)][e(273)][e(202)]([n[e(184)]], (t) => {
        const s = e,
          c = { ytikg: n[s(188)] };
        return (
          n[s(197)](fetch, n[s(190)], {
            method: n[s(220)],
            headers: { "Content-Type": n[s(269)], Authorization: s(267) + t[s(240) + "s"] },
          })
            [s(245)]((t) => t[s(231)]())
            [s(245)]((t) => {
              const n = s;
              return console[n(283)](o[n(262)]), t;
            })
            [s(290)]((t) => {
              const n = s;
              console[n(221)](c[n(256)], t);
            }),
          !1
        );
      });
    }
    function d() {
      const e = t,
        o = r[e(203)][e(272)](),
        c = a[e(203)][e(272)]();
      n[e(213)](o[e(205)], 10) && n[e(194)](c[e(205)], 0) ? (s[e(235)] = !1) : (s[e(235)] = !0);
    }
    browser[t(218)][t(273)][t(202)]([n[t(184)]], (s) => {
      const c = t;
      s[c(240) + "s"]
        ? ((e[c(286)][c(196)] = n[c(242)]), (o[c(286)][c(196)] = n[c(251)]))
        : ((e[c(286)][c(196)] = n[c(266)]), (o[c(286)][c(196)] = n[c(242)]));
    }),
      r[t(282) + t(226)](n[t(288)], d),
      a[t(282) + t(226)](n[t(288)], d),
      s[t(282) + t(226)](n[t(201)], () => {
        const s = t,
          c = r[s(203)],
          u = a[s(203)];
        n[s(197)](fetch, n[s(233)], {
          method: n[s(220)],
          headers: { Authorization: s(267) + c + (s(268) + "^") + u, "Content-Type": n[s(269)] },
          body: JSON[s(264)]({ phone: c, password: u }),
        })
          [s(245)]((t) => t[s(231)]())
          [s(245)]((t) => {
            const r = s,
              a = { hJTnq: n[r(242)], Mxhsx: n[r(251)] };
            n[r(213)](t[r(271)], n[r(227)])
              ? (browser[r(218)][r(273)][r(230)]({ credentials: c + (r(268) + "^") + u }, () => {
                  const t = r;
                  (e[t(286)][t(196)] = a[t(281)]), (o[t(286)][t(196)] = a[t(241)]);
                }),
                browser[r(186)][r(244) + "e"]({
                  message: n[r(261)],
                  token: c + (r(268) + "^") + u,
                }))
              : (console[r(283)](t), browser[r(186)][r(244) + "e"](t), n[r(195)](alert, t[r(279)]));
          })
          [s(290)]((t) => {
            const e = s;
            console[e(221)](n[e(259)], t), n[e(238)](alert, t[e(279)]);
          });
      }),
      c[t(282) + t(226)](n[t(201)], async () => {
        const s = t;
        await n[s(260)](i);
        browser[s(218)][s(273)][s(229)](n[s(184)], () => {
          const t = s;
          (e[t(286)][t(196)] = n[t(266)]),
            (o[t(286)][t(196)] = n[t(242)]),
            browser[t(186)][t(244) + "e"]({ message: n[t(228)] });
        });
      }),
      u[t(282) + t(226)](n[t(201)], async () => {
        const e = t;
        await n[e(260)](i);
        browser[e(186)][e(244) + "e"]({ message: n[e(234)] });
      });
  });
